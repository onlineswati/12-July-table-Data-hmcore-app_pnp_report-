REM INSERTING into EXPORT_TABLE
SET DEFINE OFF;
Insert into EXPORT_TABLE (RM_ID,EMP_CODE,RM_NAME,EMAIL_ID,DESCRIPTION) values (9,'E150','PINKESH','vishal.bhavsar@crifhighmark.com','RM1');
Insert into EXPORT_TABLE (RM_ID,EMP_CODE,RM_NAME,EMAIL_ID,DESCRIPTION) values (10,'E128','NIKHIL','n.bhosale@crif.com','RM2');
Insert into EXPORT_TABLE (RM_ID,EMP_CODE,RM_NAME,EMAIL_ID,DESCRIPTION) values (11,'E101','BHAKTI','bhakti.rananavare@crifhighmark.com','RM3');
